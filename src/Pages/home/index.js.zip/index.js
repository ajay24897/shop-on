import React, { useState, useEffect, Component } from "react";
import Axios from "axios";
import { useParams, useHistory } from "react-router";

import "../../Components/Widgets/index.css";
import "../../../src/index";
import useFetch from "../../Hooks/useFetch";
import { getProductForWomen } from "../../Constants/common.constant";
import { getProductsFlexUI } from "../pages.utils";

import MensShopping from ".././../Media/Images/men shope.webp";
import WomensShopping from ".././../Media/Images/women shope.png";

import airforceBanner from "../../Media/Carousel images/air-force-1-banner.jpeg";
import Appleser4Banner from "../../Media/Carousel images/banner-watch-seri4.jpeg";
import yeezyBoostBanner from "../../Media/Carousel images/yeezy bost banner.jpeg";

function Home() {
  let { id } = useParams();
  let history = useHistory();

  const [res, clearRes, fetchData] = useFetch();
  useEffect(() => {
    clearRes();
    fetchData(getProductForWomen, "get");
  }, []);
  return (
    <div style={{ padding: "5px" }}>
      <Home2 />
      <div className="home-shopefor-cnt">
        <div className={"home-shopefor-imgCnt"}>
          <div className="home-bg-shadow"></div>
          <img src={MensShopping} className={"home-shopefor-img"} />
          <button
            className="shopeForBtn"
            onClick={() => history.push("/product/men")}
          >
            Men
          </button>
        </div>
        <div className="home-shopefor-imgCnt">
          <div className="home-bg-shadow"></div>
          <img src={WomensShopping} className={"home-shopefor-img"} />
          <button
            className="shopeForBtn"
            onClick={() => history.push("/product/women")}
          >
            Women
          </button>
        </div>
      </div>

      {/* <h2>New Arrives for womens's</h2>
      <div className="product-flex">
        {res &&
          res.length > 0 &&
          res.slice(Math.max(res.length - 5, 0)).map((product, index) => (
            <div
              style={{
                display: "flex",
                flexDirection: "row",
              }}
            >
              {getProductsFlexUI(product, index, history, "/product/women")}
            </div>
          ))}
      </div> */}
    </div>
  );
}

export default Home;

var imageData = [
  {
    0: airforceBanner,
    alt: "airforce Banner",
  },
  {
    1: Appleser4Banner,
    alt: "Apple series 4 Banner",
  },
  {
    2: yeezyBoostBanner,
    alt: "yeezy Boost Banner",
  },
];

function Carousel(props) {
  const showImage = () => {
    return (
      <img
        src={imageData[props.imageShow][props.imageShow]}
        alt={imageData[props.imageShow].alt}
        title={imageData[props.imageShow].alt}
        style={{ width: "100%", height: 500 }}
      />
    );
  };

  return <div className="carousel">{showImage()}</div>;
}

function CarouselControl(props) {
  return (
    <div>
      <button onClick={() => props.prev}>Prev</button>
      <button onClick={() => props.next}>Next</button>
    </div>
  );
}

function Home2() {
  const [imageShow, setImageShow] = useState(0);

  useEffect(() => {
    slideShow();

    return () => {
      clearInterval(slideShow);
    };
  }, []);

  const prev = () => {
    if (imageShow === 0) {
      setImageShow(imageData.length - 1);
    } else {
      setImageShow(imageShow - 1);
    }
  };

  const next = () => {
    if (imageShow === imageData.length - 1) {
      setImageShow(0);
    } else {
      setImageShow(imageShow + 1);
    }
  };

  const slideShow = () => {
    setInterval(() => next(), 1000);
  };

  return (
    <div className="container">
      <h2>Carousel Example</h2>
      <Carousel imageShow={imageShow} />
      <CarouselControl prev={() => prev()} next={() => next()} />
    </div>
  );
}
