export const LoadeReducer = (state = false, action) => {
  switch (action.type) {
    case "isLoader":
      return action.payload;

    default:
      return state;
  }
};
