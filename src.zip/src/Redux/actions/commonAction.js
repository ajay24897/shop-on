export const isLoading = (payload) => {
  return {
    type: "isLoader",
    payload,
  };
};
