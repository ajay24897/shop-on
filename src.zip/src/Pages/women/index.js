import React, { useEffect, useState } from "react";
import Axios from "axios";

import { useParams, useHistory } from "react-router";
import { getProductForWomen } from "../../Constants/common.constant";
import { capitalizeFirstLetter } from "../pages.utils";

function Women() {
  let { id } = useParams();
  let history = useHistory();

  const [allProducts, setAllProducts] = useState([]);
  const [product, setProduct] = useState([]);

  useEffect(() => {
    console.log(id);
    if (id) {
      setAllProducts([]);
      Axios.get(getProductForWomen + `/${id}`)
        .then((res) => {
          console.log("responce", res.data);
          setProduct(res.data);
        })
        .catch((error) => {});
    } else {
      setProduct([]);
      Axios.get(getProductForWomen)
        .then((res) => {
          console.log("res", res.data);
          setAllProducts(res.data);
        })
        .catch((error) => {});
    }
  }, [id]);

  // const capitalizeFirstLetter = (str) => {
  //   const newStr = `${str[0].toUpperCase()}${str.slice(1).toLowerCase()}`;
  //   return newStr;
  // };

  return (
    <div className="product-grid" style={{ overflow: "hidden" }}>
      {id
        ? product.map((item, index) => (
            <div
              className="image-cnt"
              key={index}
              onClick={() => {
                // history.push(`/product/men/${item.id}`);
              }}
            >
              <img
                className={"productImg  image"}
                src={`http://localhost:4000/images/${item.file}`}
                alt={"item.shoe_name"}
                loading={index > 8 ? "lazy" : null}
              />

              <div className="short-product-details">
                <h2 className="text-ellipsis">
                  {capitalizeFirstLetter(item.brand)}
                </h2>
                <h4 className="text-ellipsis">
                  {capitalizeFirstLetter(item.name)}
                </h4>
                <h4>$ {item.price}</h4>
              </div>
            </div>
          ))
        : allProducts.map((item, index) => (
            <div
              className="image-cnt"
              key={index}
              onClick={() => {
                history.push(`/product/women/${item.id}`);
              }}
            >
              <img
                className={"productImg  image"}
                src={`http://localhost:4000/images/${item.file}`}
                alt={"item.shoe_name"}
                loading={index > 8 ? "lazy" : null}
              />

              <div className="short-product-details">
                <h2 className="text-ellipsis">
                  {capitalizeFirstLetter(item.brand)}
                </h2>
                <h4 className="text-ellipsis">
                  {capitalizeFirstLetter(item.name)}
                </h4>
                <h4>$ {item.price}</h4>
              </div>
            </div>
          ))}
    </div>
  );
}

export default Women;

// backgroundPosition: ` ${mouseX} ${mouseY} !important`,
