import Axios from "axios";

export const capitalizeFirstLetter = (str) => {
  const newStr = `${str[0].toUpperCase()}${str.slice(1).toLowerCase()}`;
  return newStr;
};

export const fetchAPI = async (url, type, data) => {
  if (type === "get")
    try {
      let fetch = Axios.get(url);
      return fetch;
    } catch (error) {
      return error;
    }
};
