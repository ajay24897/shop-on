import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router";
import { useDispatch } from "react-redux";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";

import Axios from "axios";

import "../../Components/Widgets/index.css";
import "../../../src/index";
import { isLoading } from "../../Redux/actions/commonAction";
import { getProductForMen } from "../../Constants/common.constant";
import { capitalizeFirstLetter } from "../pages.utils";
import useFetch from "../../Hooks/callApi";

function Men() {
  let { id } = useParams();
  let history = useHistory();
  const disatch = useDispatch();

  const [allProducts, setAllProducts] = useState([]);
  const [product, setProduct] = useState([]);

  const [res, fetchData] = useFetch();

  useEffect(() => {
    console.log("res", res);
  }, [res]);

  useEffect(() => {
    console.log(id);
    if (id) {
      setAllProducts([]);
      // disatch(isLoading(true));
      fetchData(getProductForMen + `/${id}`, "get");

      // Axios.get(getProductForMen + `/${id}`)
      //   .then((res) => {
      //     console.log("responce", res.data);
      //     setProduct(res.data);
      //     disatch(isLoading(false));
      //   })
      //   .catch((error) => {
      //     disatch(isLoading(false));
      //   });
    } else {
      setProduct([]);
      // disatch(isLoading(true));
      fetchData(getProductForMen, "get");

      // Axios.get(getProductForMen)
      //   .then((res) => {
      //     console.log("res", res.data);
      //     setAllProducts(res.data);
      //     disatch(isLoading(false));
      //   })
      //   .catch((error) => {
      //     disatch(isLoading(false));
      //   });
    }
  }, [id]);

  return (
    <div className="product-grid" style={{ overflow: "hidden" }}>
      {res &&
        res.map((item, index) => (
          <div
            className="image-cnt"
            key={index}
            onClick={() => {
              history.push(`/product/men/${item.id}`);
            }}
          >
            <LazyLoadImage
              className={"productImg  image"}
              src={`http://localhost:4000/images/${item.file}`}
              alt={item.shoe_name}
              effect="blur"
            />

            <div className="short-product-details">
              <h2 className="text-ellipsis">
                {capitalizeFirstLetter(item.brand)}
              </h2>
              <h4 className="text-ellipsis">
                {capitalizeFirstLetter(item.name)}
              </h4>
              <h4>$ {item.price}</h4>
            </div>
          </div>
        ))}
    </div>
  );
}

export default Men;
