export const BaseURL = `http://localhost:4000/api/`;
export const getProductForMen = BaseURL + `getProductForMen`;
export const getProductForWomen = BaseURL + `getProductForWomen`;
