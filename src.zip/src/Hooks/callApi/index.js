import Axios from "axios";
import { useState, useEffect } from "react";
import { useDispatch } from "react-redux";
import { isLoading } from "../../Redux/actions/commonAction";

function useFetch() {
  const dispatch = useDispatch();
  const [res, setRes] = useState();

  async function fetchData(url, type, data) {
    if (type == "get") {
      try {
        dispatch(isLoading(true));
        let responce = await Axios.get(url);
        setRes(responce.data);
        dispatch(isLoading(false));
      } catch (error) {
        setRes(error);
        dispatch(isLoading(false));
      }
    }
  }
  return [
    res,
    (url, type, data) => {
      fetchData(url, type, data);
    },
  ];
}
export default useFetch;

//   let res = useFetch(getProductForMen, "get");
