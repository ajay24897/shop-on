import Axios from "axios";
import { LazyLoadImage } from "react-lazy-load-image-component";

import "react-lazy-load-image-component/src/effects/blur.css";
import { fetchImageURL } from "../Constants/common.constant";

export const capitalizeFirstLetter = (str) => {
  const newStr = `${str[0].toUpperCase()}${str.slice(1).toLowerCase()}`;
  return newStr;
};

export const fetchAPI = async (url, type, data) => {
  if (type === "get") {
    try {
      let fetch = Axios.get(url);
      return fetch;
    } catch (error) {
      return error;
    }
  }
};

export const getProductFullInfo = (brand, name, description, price) => {
  return (
    <div className="long-product-details">
      <h1 className="margin-b-10">{capitalizeFirstLetter(brand)}</h1>
      <h2 className="margin-b-10">{capitalizeFirstLetter(name)}</h2>
      <p className="margin-b-10">{capitalizeFirstLetter(description)}</p>
      <h2 className="margin-b-10">$ {price}</h2>
    </div>
  );
};
export const getProductShortInfo = (brand, name, price) => {
  return (
    <div className="short-product-details">
      <h2 className="text-ellipsis margin-b-5">
        {capitalizeFirstLetter(brand)}
      </h2>
      <h4 className="text-ellipsis margin-b-5">
        {capitalizeFirstLetter(name)}
      </h4>
      <h4 className="text-ellipsis margin-b-5">$ {price}</h4>
    </div>
  );
};

export const getLazyLoadImage = (url, altName, className) => {
  return (
    <div>
      <LazyLoadImage
        className={className}
        src={url}
        alt={altName}
        effect="blur"
      />
    </div>
  );
};

export const getProductsGridUI = (product, index, history, route) => {
  console.log("product", product);
  return (
    <div
      data-aos="zoom-in"
      data-aos-duration="1000"
      className="image-cnt"
      key={index}
      onClick={() => {
        history.push(`${route}/${product.id}`);
      }}
    >
      <div className="flex-r-center">
        {getLazyLoadImage(
          fetchImageURL + product.file,
          product.name,
          "productImg  image"
        )}
      </div>
      {getProductShortInfo(product.brand, product.name, product.price)}
    </div>
  );
};

export const getProductUI = (product, index) => {
  return (
    <div
      className="single-product-cnt"
      key={index}
      data-aos="zoom-in"
      data-aos-duration="1500"
    >
      <div className="single-product-cnt">
        {getLazyLoadImage(
          fetchImageURL + product.file,
          product.name,
          "single-productImg  image"
        )}
      </div>
      {getProductFullInfo(
        product.brand,
        product.name,
        product.description,
        product.price
      )}
    </div>
  );
};

export const getProductsFlexUI = (product, index, history, route) => {
  console.log("product", product);
  return (
    <>
      <div
        data-aos="zoom-in"
        data-aos-duration="1000"
        className="image-cnt"
        key={index}
        onClick={() => {
          history.push(`${route}/${product.id}`);
        }}
      >
        <div className="flex-r-center">
          {getLazyLoadImage(
            fetchImageURL + product.file,
            product.name,
            "productImg  image"
          )}
        </div>
        {getProductShortInfo(product.brand, product.name, product.price)}
      </div>
    </>
  );
};
