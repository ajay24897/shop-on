import React, { useState, useEffect, Component } from "react";
import Axios from "axios";
import { useParams, useHistory } from "react-router";

import "../../Components/Widgets/index.css";
import "../../../src/index";
import useFetch from "../../Hooks/useFetch";
import { getProductForWomen } from "../../Constants/common.constant";
import { getProductsFlexUI } from "../pages.utils";

function Home() {
  let { id } = useParams();
  let history = useHistory();

  const [res, clearRes, fetchData] = useFetch();
  useEffect(() => {
    clearRes();
    fetchData(getProductForWomen, "get");
  }, []);
  return (
    <div style={{ padding: "5px" }}>
      <h2>New Arrives for womens's</h2>
      <div className="product-flex">
        {res &&
          res.length > 0 &&
          res.slice(Math.max(res.length - 5, 0)).map((product, index) => (
            <div
              style={{
                display: "flex",
                flexDirection: "row",
              }}
            >
              {getProductsFlexUI(product, index, history, "/product/women")}
            </div>
          ))}
      </div>
    </div>
  );
}

export default Home;

// var imageData = [
//   {
//     0: "https://images.unsplash.com/photo-1484256017452-47f3e80eae7c?ixlib=rb-0.3.5&s=f1af676eceb49746407f0f418349b962&auto=format&fit=crop&w=750&q=80",
//     alt: "yellow",
//   },
//   {
//     1: "https://images.unsplash.com/photo-1481349518771-20055b2a7b24?ixlib=rb-0.3.5&s=0ca09cf5f08182a9b6f57ddeec3496a2&auto=format&fit=crop&w=809&q=80",
//     alt: "pink",
//   },
//   {
//     2: "https://images.unsplash.com/photo-1454944338482-a69bb95894af?ixlib=rb-0.3.5&s=11f983c05692c1f90c13b2e8e34793ac&auto=format&fit=crop&w=752&q=80",
//     alt: "white",
//   },
// ];

// function Carousel(props) {
//   const showImage = () => {
//     return (
//       <img
//         src={imageData[props.imageShow][props.imageShow]}
//         alt={imageData[props.imageShow].alt}
//         title={imageData[props.imageShow].alt}
//         style={{ width: "100%", height: 500 }}
//       />
//     );
//   };

//   return <div className="carousel">{showImage()}</div>;
// }

// function CarouselControl(props) {
//   return (
//     <div>
//       <button onClick={() => props.prev}>Prev</button>
//       <button onClick={() => props.next}>Next</button>
//     </div>
//   );
// }

// function Home() {
//   const [imageShow, setImageShow] = useState(0);

//   useEffect(() => {
//     slideShow();

//     return () => {
//       clearInterval(slideShow);
//     };
//   }, []);

//   const prev = () => {
//     if (imageShow === 0) {
//       setImageShow(imageData.length - 1);
//     } else {
//       setImageShow(imageShow - 1);
//     }
//   };

//   const next = () => {
//     if (imageShow === imageData.length - 1) {
//       setImageShow(0);
//     } else {
//       setImageShow(imageShow + 1);
//     }
//   };

//   const slideShow = () => {
//     setInterval(() => next(), 1000);
//   };

//   return (
//     <div className="container">
//       <h2>Carousel Example</h2>
//       <Carousel imageShow={imageShow} />
//       <CarouselControl prev={() => prev()} next={() => next()} />
//     </div>
//   );
// }
// export default Home;
