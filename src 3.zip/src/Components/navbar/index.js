import React from "react";

import "../../index.css";

import DesktopNavigation from "./desktopNavigation";
import MobileNavigation from "./mobileNavigation";
function Navbar() {
  return (
    <div className="navbarWrapper">
      <DesktopNavigation />
      <MobileNavigation />
    </div>
  );
}

export default Navbar;
