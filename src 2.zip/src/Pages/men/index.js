import React, { useEffect } from "react";
import { useParams, useHistory } from "react-router";
import { LazyLoadImage } from "react-lazy-load-image-component";
import "react-lazy-load-image-component/src/effects/blur.css";
import "../../Components/Widgets/index.css";
import "../../../src/index";
import {
  fetchImageURL,
  getProductForMen,
} from "../../Constants/common.constant";
import {
  getProductShortInfo,
  getProductFullInfo,
  getLazyLoadImage,
} from "../pages.utils";
import useFetch from "../../Hooks/useFetch";

function Men() {
  let { id } = useParams();
  let history = useHistory();

  const [res, clearRes, fetchData] = useFetch();

  useEffect(() => {
    if (id) {
      clearRes([]);
      fetchData(getProductForMen + `/${id}`, "get");
    } else {
      clearRes([]);

      fetchData(getProductForMen, "get");
    }
  }, [id]);

  return !id ? (
    <div className="product-grid" style={{ overflow: "hidden" }}>
      {res &&
        res.length > 0 &&
        res.map((product, index) => (
          <div
            data-aos="zoom-in"
            data-aos-duration="1000"
            className="image-cnt"
            key={index}
            onClick={() => {
              history.push(`/product/men/${product.id}`);
            }}
          >
            <div className="flex-r-center">
              <LazyLoadImage
                className={"productImg  image"}
                src={fetchImageURL + `${product.file}`}
                alt={product.name}
                effect="blur"
              />
            </div>
            {getProductShortInfo(product.brand, product.name, product.price)}
          </div>
        ))}
    </div>
  ) : (
    <div>
      {res &&
        res.length > 0 &&
        res.map((product, index) => (
          <div
            className="single-product-cnt"
            key={index}
            data-aos="zoom-in"
            data-aos-duration="1500"
          >
            <div className="single-product-cnt">
              <LazyLoadImage
                className={"single-productImg  image"}
                src={fetchImageURL + `${product.file}`}
                alt={product.name}
                effect="blur"
              />
            </div>
            {getProductFullInfo(
              product.brand,
              product.name,
              product.description,
              product.price
            )}
          </div>
        ))}
    </div>
  );
}

export default Men;

// function Zoom({ id }) {
//   const [BGP, setBGP] = useState({
//     backgroundPosition: "0% 0%",
//     backgroundImage: `url(${fetchImageURL + id})`,
//   });
//   useEffect(() => {});

//   let handleMouseMove = (e) => {
//     const { left, top, width, height } = e.target.getBoundingClientRect();
//     const x = ((e.pageX - left) / width) * 100;
//     const y = ((e.pageY - top) / height) * 100;
//     setBGP({
//       backgroundPosition: `${x}% ${y}% !important`,
//       backgroundImage: `url(${fetchImageURL + `4`}) !important`,
//     });
//   };

//   return (
//     <figure onMouseMove={handleMouseMove} style={BGP}>
//       <img src={fetchImageURL + id} />
//     </figure>
//   );
// }
