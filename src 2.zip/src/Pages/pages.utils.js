import Axios from "axios";
import { LazyLoadImage } from "react-lazy-load-image-component";

import "react-lazy-load-image-component/src/effects/blur.css";

export const capitalizeFirstLetter = (str) => {
  const newStr = `${str[0].toUpperCase()}${str.slice(1).toLowerCase()}`;
  return newStr;
};

export const fetchAPI = async (url, type, data) => {
  if (type === "get") {
    try {
      let fetch = Axios.get(url);
      return fetch;
    } catch (error) {
      return error;
    }
  }
};

export const getProductFullInfo = (brand, name, description, price) => {
  return (
    <div className="long-product-details">
      <h1 className="margin-v-10">{capitalizeFirstLetter(brand)}</h1>
      <h2 className="margin-v-10">{capitalizeFirstLetter(name)}</h2>
      <p className="margin-v-10">{capitalizeFirstLetter(description)}</p>
      <h2 className="margin-v-10">$ {price}</h2>
    </div>
  );
};
export const getProductShortInfo = (brand, name, price) => {
  return (
    <div className="short-product-details">
      <h2 className="text-ellipsis">{capitalizeFirstLetter(brand)}</h2>
      <h4 className="text-ellipsis">{capitalizeFirstLetter(name)}</h4>
      <h4>$ {price}</h4>
    </div>
  );
};

export const getLazyLoadImage = (url, altName) => {
  return (
    <div>
      <LazyLoadImage
        className={"single-productImg  image"}
        src={url}
        alt={altName}
        effect="blur"
      />
    </div>
  );
};
