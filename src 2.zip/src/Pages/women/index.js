import React, { useEffect } from "react";
import { LazyLoadImage } from "react-lazy-load-image-component";
import { useParams, useHistory } from "react-router";
import {
  fetchImageURL,
  getProductForWomen,
} from "../../Constants/common.constant";
import {
  getLazyLoadImage,
  getProductFullInfo,
  getProductShortInfo,
} from "../pages.utils";
import useFetch from "../../Hooks/useFetch";
import "react-lazy-load-image-component/src/effects/blur.css";

function Women() {
  let { id } = useParams();
  let history = useHistory();

  const [res, clearRes, fetchData] = useFetch();

  useEffect(() => {
    if (id) {
      clearRes();
      fetchData(getProductForWomen + `/${id}`, "get");
    } else {
      clearRes();
      fetchData(getProductForWomen, "get");
    }
  }, [id]);

  return !id ? (
    <div className="product-grid" style={{ overflow: "hidden" }}>
      {res &&
        res.length > 0 &&
        res.map((product, index) => (
          <div
            data-aos="zoom-in"
            data-aos-duration="1000"
            className="image-cnt"
            key={index}
            onClick={() => {
              history.push(`/product/women/${product.id}`);
            }}
          >
            <div className="flex-r-center">
              <LazyLoadImage
                className={"productImg  image"}
                src={fetchImageURL + `${product.file}`}
                alt={product.name}
                effect="blur"
              />
            </div>
            {getProductShortInfo(product.brand, product.name, product.price)}
          </div>
        ))}
    </div>
  ) : (
    <div>
      {res &&
        res.length > 0 &&
        res.map((product, index) => (
          <div
            className="single-product-cnt"
            key={index}
            data-aos="zoom-in"
            data-aos-duration="1500"
          >
            <div className="single-product-cnt">
              {getLazyLoadImage(fetchImageURL + product.file, product.name)}
              {/* <LazyLoadImage
                className={"single-productImg  image"}
                src={fetchImageURL + `${product.file}`}
                alt={product.name}
                effect="blur"
              /> */}
            </div>
            {getProductFullInfo(
              product.brand,
              product.name,
              product.description,
              product.price
            )}
          </div>
        ))}
    </div>
  );
}

export default Women;
