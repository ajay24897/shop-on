import React from "react";

function Footer() {
  return <div style={{ height: 40, background: "green" }}></div>;
}

export default Footer;
