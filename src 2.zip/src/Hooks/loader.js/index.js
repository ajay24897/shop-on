import React, { useState } from "react";
import "./style.css";

function Loader() {
  return (
    <div className="loader-cnt">
      <div className="loader" />
    </div>
  );
}
export default Loader;
